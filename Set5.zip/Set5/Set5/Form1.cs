﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Set5
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\dot net\\Set5\\dbSet5_1.mdf\";Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
            txtProductId.Enabled = false;
            ex();
        }

        private void ex()
        {
            query = "select Category_ID,Category_Name from Category";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbcat.DataSource = dt;
            cmbcat.ValueMember = "Category_ID";
            cmbcat.DisplayMember = "Category_Name";

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtPrice.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtProductName.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtProductName.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(cmbcat.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                cmbcat.Focus();
                return;
            }
            else
            {
                String name = txtProductName.Text;
                decimal price = Convert.ToDecimal(txtPrice.Text);
                int cat = int.Parse(cmbcat.SelectedValue.ToString());
                query = "Insert into Product (Product_Name,Price,Category_ID) values ('"+name+"',"+price+","+cat+")";
                MessageBox.Show(query);
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted...");
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Record  Updated...");
            query = "Select * from Product";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);//fills data to data table from adapter
            dg1.DataSource = dt;
        }

        private void txtProductName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }
    }
}
