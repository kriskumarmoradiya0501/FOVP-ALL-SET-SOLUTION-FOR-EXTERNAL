﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace p2
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\db_con\\db_dabas1.mdf;Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
            ex2();
            ex();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtElevation.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtElevation.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtHealth.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtHealth.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtLatitude.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtLatitude.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtLongitude.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtLongitude.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtSid.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtSid.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtSname.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtSname.Focus();
                return;
            }
            else
            {
                String id = txtSid.Text, name = txtSname.Text, health = txtHealth.Text;
                float longitude = float.Parse(txtLatitude.Text), latitude = float.Parse(txtLatitude.Text);
                int elevation = int.Parse(txtElevation.Text);

                query = "Insert into SATELLITE_TB2(SatelliteID,SatelliteName,Longitube,Latitude,Elevation,HealthStatus)" +
                   " Values ('" + id + "','" + name
                    + "',"
                   + longitude + "," + latitude + ","
                   + elevation + ",'active')";
                //query = "Insert into SATELLITE_TB(SatelliteID,SatelliteName,Longitube,Latitude,Elevation,HealthStatus) values('df','dfs',10,10,10,'active')";
                MessageBox.Show(query);
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Record  Inderted...");
                txtSid.Clear();
                txtElevation.Clear();
                txtHealth.Clear();
                txtLatitude.Clear();
                txtLongitude.Clear();
                txtSname.Clear();
            }
        }
        private void ex()
        {
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
           // MessageBox.Show("Record  Updated...");
            query = "Select * from SATELLITE_TB2";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);//fills data to data table from adapter
            dg1.DataSource = dt;


        }

        private void ex2()
        {
            query = "Select SatelliteID,SatelliteName from SATELLITE_TB2";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt); // Fills data to data table from adapter
            cmbSname.DataSource = dt;
            cmbSname.ValueMember = "SatelliteID"; // Changed "PID" to "bid" to match the column name
            cmbSname.DisplayMember = "SatelliteName"; // Added DisplayMember to show the bid values in the ComboBox
            ex();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtSid.Clear();
            txtElevation.Clear();
            txtHealth.Clear();
            txtLatitude.Clear();
            txtLongitude.Clear();
            txtSname.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtElevation.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtElevation.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtHealth.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtHealth.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtLatitude.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtLatitude.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtLongitude.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtLongitude.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtSid.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtSid.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtSname.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtSname.Focus();
                return;
            }
            else
            {
                String id = txtSid.Text, name = txtSname.Text, health = txtHealth.Text;
                float longitude = float.Parse(txtLatitude.Text), latitude = float.Parse(txtLatitude.Text);
                int elevation = int.Parse(txtElevation.Text);
                query = "Update SATELLITE_TB2 set  SatelliteName = '" + name + "',Longitube = " + longitude + ",Latitude = " + latitude + "," +
                    "Elevation = " + elevation + ",HealthStatus = '" + health + "' " +
                    "where SatelliteID = '" + id + "'";
                MessageBox.Show(query);

                ex();
                ex2();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            query = "Delete from SATELLITE_TB2" +
                " where SatelliteID = '" + txtSid.Text + "'";
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record  Deleted...");

            ex();
            ex2();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Safely bind the parameter to avoid SQL injection
            string query = "SELECT * FROM SATELLITE_TB2 WHERE SatelliteID = '"+cmbSname.Text+"'";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                
                // Execute the query and retrieve data
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        // Populate the fields from the result
                        txtSid.Text = dr["SatelliteID"].ToString();
                        txtSname.Text = dr["SatelliteName"].ToString();
                        txtLatitude.Text = dr["Latitude"].ToString();
                        txtLongitude.Text = dr["Longitube"].ToString();  // Corrected field
                        txtElevation.Text = dr["Elevation"].ToString();
                        txtHealth.Text = dr["HealthStatus"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No record found for the provided Satellite ID.");
                    }
                }
            }
        }

        private void txtSid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }

        private void txtHealth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }

        private void txtLongitude_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }

        private void txtLatitude_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                return;
            }
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
        }
    }
}
