﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Set4
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\dot net\\Set4\\db_set4_1.mdf\";Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
            txtName.Enabled = false;
            txtGrade.Enabled = false;
            cmbCourseId.Enabled = true;
            cmbStudentId.Enabled = false;
            btnSave.Enabled = false;
            ex();
        }
        private void ex()
        {
            query = "Select Course_ID,Course_Name from Course";
            SqlDataAdapter da = new SqlDataAdapter(query,conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbCourseId.DataSource = dt;
            cmbCourseId.ValueMember = "Course_ID";
            cmbCourseId.DisplayMember = "Course_Name";
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            txtName.Enabled = true;
            txtGrade.Enabled = true;
            cmbCourseId.Enabled = true;
            cmbStudentId.Enabled = false;
            btnSave.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtGrade.Text))
            {
                MessageBox.Show("Enter Grade : ");
                txtGrade.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtName.Text))
            {
                MessageBox.Show("Enter Name : ");
                txtName.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(cmbCourseId.Text))
            {
                MessageBox.Show("Enter Course : ");
                cmbCourseId.Focus();
                return;
            }
            else
            {
                string name = txtName.Text, grade = txtGrade.Text;
                int id = int.Parse(cmbCourseId.SelectedValue.ToString());
                query = "Insert into Student (Name,Course_ID,Grade) Values ('"+name+"',"+id+",'"+grade+"')";
                MessageBox.Show(query);
                cmd = new SqlCommand(query,conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted");
            }
        }

        private void ex2()
        {
            cmd = new SqlCommand(  query,conn);
            cmd.ExecuteNonQuery();

            query = "Select * from Student";
            SqlDataAdapter da = new SqlDataAdapter(query,conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dg1.DataSource = dt;
        }

        private void ex3()
        {
            query = "Select Student_ID from Student";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbStudentId.DataSource = dt;
            cmbStudentId.ValueMember = "Student_ID";
            cmbStudentId.DisplayMember = "Student_ID";
        }
        private void btnView_Click(object sender, EventArgs e)
        {
            ex2();
            ex3();
            cmbStudentId.Enabled = true;
        }
    }
}
