﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Set6
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            String connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\dot net\\Set6\\dbset6.mdf\";Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
            txtCustomerName.Enabled = false;
            txtOrderId.Enabled = false;
            txtQty.Enabled = false;
            txtTotal.Enabled = false;
            ex2();
            ex1();
        }

        private void ex1()
        {
            query = "select Dish_Name,Menu_ID from Menu";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt); // Fills data to data table from adapter
            cmbMenuId.DataSource = dt;
            cmbMenuId.ValueMember = "Menu_ID"; // Changed "PID" to "bid" to match the column name
            cmbMenuId.DisplayMember = "Dish_Name"; // Added DisplayMember to show the bid values in the ComboBo

        }
        private void ex2()
        {
            query = "select Customer_Name,Order_ID from Order1";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt); // Fills data to data table from adapter
            cmbCustomerName.DataSource = dt;
            cmbCustomerName.ValueMember = "Order_ID"; // Changed "PID" to "bid" to match the column name
            cmbCustomerName.DisplayMember = "Customer_Name"; // Added DisplayMember to show the bid values in the ComboBo

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            ex();
            txtCustomerName.Enabled=true;
            txtOrderId.Enabled=false;
            txtQty.Enabled=true;
            txtTotal.Enabled=true;
        }

        private void ex()
        {
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Record  Updated...");
            int cid = int.Parse(cmbCustomerName.SelectedValue.ToString());

            query = "Select * from Order1 Where Order_ID = " + cid;
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);//fills data to data table from adapter
            dg1.DataSource = dt;


        }

        private void txtQty_Leave(object sender, EventArgs e)
        {
            string query = $"SELECT Price FROM Menu WHERE Menu_ID = "+ int.Parse(cmbCustomerName.SelectedValue.ToString());
            SqlCommand cmd = new SqlCommand(query, conn);
            txtTotal.Text = Convert.ToString(int.Parse(txtQty.Text) * Convert.ToDecimal(cmd.ExecuteScalar())+0);

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerName.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtCustomerName.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtTotal.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtTotal.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtQty.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtQty.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(cmbMenuId.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                cmbMenuId.Focus();
                return;
            }
            else
            {
                string name = txtCustomerName.Text;
                int mid = int.Parse(cmbMenuId.SelectedValue.ToString());
                int qty = int.Parse(txtQty.Text);
                decimal total = decimal.Parse(txtTotal.Text);
                query = "Insert into Order1(Customer_Name,Menu_ID,Quantity,Total_Amount) values ('"+name+"',"+mid+","+qty+","+total+")";
                MessageBox.Show(query);
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            ex1();
            ex();
            ex2();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int orderId = Convert.ToInt32(cmbCustomerName.SelectedValue);

            query = "Delete from Order1 where Order_ID = " +orderId;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();

            ex1();
            ex();
            ex2();
        }
    }
}
