﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Set2
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtID.Enabled = false;
            txtPrice.Enabled = false;
            txtTitle.Enabled = false;
            btnDelete.Enabled = false;
            cmbAuthor_Name.Enabled = false;
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\dot net\\Set2_DB\\BookStore_DB1.mdf\";Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();

            ex2();

        }

        private void ex2()
        {
            query = "Select Author_ID,Author_Name from Author";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt); // Fills data to data table from adapter
            cmbAuthor.DataSource = dt;
            cmbAuthor.ValueMember = "Author_ID"; // Changed "PID" to "bid" to match the column name
            cmbAuthor.DisplayMember = "Author_Name"; // Added DisplayMember to show the bid values in the ComboBox
        }


        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                txtID.Text = dataGridView1.SelectedRows[0].Cells["Book_ID"].Value.ToString();
                txtTitle.Text = dataGridView1.SelectedRows[0].Cells["Title"].Value.ToString();
                txtPrice.Text = dataGridView1.SelectedRows[0].Cells["Price"].Value.ToString();
                cmbAuthor.SelectedValue = dataGridView1.SelectedRows[0].Cells["Author_ID"].Value;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            ex();
        }
        private void ex()
        {
            int authorId = (int)cmbAuthor.SelectedValue;
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Record  Updated...");
            query = "Select * from Books where Author_ID = "+authorId;
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);//fills data to data table from adapter
            dataGridView1.DataSource = dt;

            txtTitle.Enabled = true;
            txtPrice.Enabled = true;
            cmbAuthor_Name.Enabled = false;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Enter Book Title : ");
                txtTitle.Focus();
                return;
            }
            
            else if (string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Enter Book Price : ");
                txtPrice.Focus();
                return;
            }
            else
            {
                String Title = txtTitle.Text;
                float price = float.Parse(txtPrice.Text);
                int Id= int.Parse(txtID.Text);
                query = "Update Books set  Title = '" +Title + "',Price = " + price + 
                    " where Book_ID = " + Id ;
                MessageBox.Show(query);

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            query = "Delete from Books" +
               " where Book_ID = '" + txtID.Text + "'";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record  Deleted...");

                ex();
                ex2();
            
        }
    }
}
