﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Set_3
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\dot net\\Set_3\\set31.mdf\";Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
            btnInsert.Enabled = true;
            btnUpdate.Enabled = true;
            btnSave.Enabled = false;
            txtTitle.Enabled = false;
            txtDirName.Enabled = false;
            txtYear.Enabled = false;
            cmbGenre.Enabled = false;
            cmbMovieId.Enabled = false;

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            btnInsert.Enabled = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            txtTitle.Enabled = true;
            txtDirName.Enabled = true;
            txtYear.Enabled = true;
            cmbGenre.Enabled = true;
            cmbMovieId.Enabled = false;
        }

        private void ex2()
        {
            query = "Select Movie_ID from Movie";
            SqlDataAdapter da = new SqlDataAdapter(query,conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbMovieId.DataSource = dt;
            cmbMovieId.ValueMember = "Movie_ID";
            cmbMovieId.DisplayMember = "Movie_ID";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ex2();
            
            string title = txtTitle.Text,dir = txtDirName.Text;
            int relyear= int.Parse(txtYear.Text);

            query = "Insert into Movie (Movie_Title,Director_Name,Release_Year,Genre) Values ('" + title+"','"+dir+"',"+relyear+",'"+cmbGenre.Text+"')";
            MessageBox.Show(query);
            cmd = new SqlCommand(query,conn);
            cmd.ExecuteNonQuery();
            ex2();
            MessageBox.Show("Inserted...");
            cmbMovieId.Enabled = true;
            btnSave.Enabled = false;
            btnInsert.Enabled = true;
            btnUpdate.Enabled = true;

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ex2();
            btnInsert.Enabled = false;
            btnUpdate.Enabled = false;

        }

        private void cmbMovieId_Click(object sender, EventArgs e)
        {
            string query = "Select * from Movie where Movie_ID = '" + cmbMovieId.Text + "'";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        txtTitle.Text = dr["Movie_Title"].ToString();
                        txtDirName.Text = dr["Director_Name"].ToString();
                        txtYear.Text = dr["Release_Year"].ToString();
                        cmbGenre.Text = dr["Genre"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Not found");
                    }
                }
            }
        }
    }
}
